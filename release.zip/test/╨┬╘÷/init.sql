CREATE TABLE test1 (
	test_id  varchar(255),
	test_name  varchar(32),
	PRIMARY KEY (test_id)
)